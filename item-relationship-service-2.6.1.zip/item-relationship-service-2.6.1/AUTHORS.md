# Authors

The following people have contributed to this repository:

- Jaro Hartmann, doubleSlash Net-Business GmbH, https://github.com/ds-jhartmann
- Jan Kreutzfeld, doubleSlash Net-Business GmbH, https://github.com/ds-jkreutzfeld
- Martin Kanal, doubleSlash Net-Business GmbH, https://github.com/mkanal
- Johannes Zahn, BMW Group, https://github.com/jzbmw
- Oladapo Oyeneye, doubleSlash Net-Business GmbH, https://github.com/ds-ext-ooyeneye
- Krzysztof Massalski, doubleSlash Net-Business GmbH, https://github.com/ds-ext-kmassalski
- Sebastian Scherer, Mercedes Benz AG, https://github.com/the-tatanka
- Saber Dridi, ISTOS GmbH, https://github.com/SaberIstos
- Andreas Genz, doubleSlash Net-Business GmbH, https://github.com/ds-agenz
- Alexander Bulgakov, doubleSlash Net-Business GmbH, https://github.com/ds-alexander-bulgakov
- Michael Schlacher, doubleSlash Net-Business GmbH, https://github.com/michaelschlacher2
- Sebastian Bezold, Mercedes Benz AG, https://github.com/SebastianBezold
- Zied Belkhiria, MHP, https://github.com/Zied-Belkhiria-Mhp
- Adam Bugajewski, doubleSlash Net-Business GmbH, https://github.com/ds-ext-abugajewski